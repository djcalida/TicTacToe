﻿using Microsoft.AspNetCore.SignalR;

public class GameHub : Hub
{
    private static Dictionary<string, string> playerTurns = new Dictionary<string, string>();

    public async Task MakeMove(string gameId, int x, int y)
    {
        if (!playerTurns.ContainsKey(gameId))
        {
            playerTurns[gameId] = "X"; // First move is always "X"
        }

        string currentPlayer = playerTurns[gameId];

        await Clients.All.SendAsync("ReceiveMove", currentPlayer, x, y);

        // Switch turn
        playerTurns[gameId] = (currentPlayer == "X") ? "O" : "X";
    }

    public async Task RestartGame()
    {
        await Clients.All.SendAsync("GameRestarted");
    }
}
