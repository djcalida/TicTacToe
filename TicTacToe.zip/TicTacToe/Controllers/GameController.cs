﻿using Microsoft.AspNetCore.Mvc;

namespace Tic_Tac_Toe.Controllers;

public class GameController : Controller
{
    public IActionResult Index() // Co-op Mode
    {
        return View("Coop");
    }

    public IActionResult Multiplayer()
    {
        return View();
    }

    public IActionResult Bots()
    {
        return View();
    }
}
