﻿document.addEventListener("DOMContentLoaded", () => {
    const board = ["", "", "", "", "", "", "", "", ""];
    let currentPlayer = "X";
    let gameActive = true;
    const statusText = document.getElementById("status");
    const restartButton = document.getElementById("restart-game");
    const cells = document.querySelectorAll(".cell");

    // Scoreboard variables (resets when the page reloads)
    let scoreX = 0;
    let scoreO = 0;

    // Get scoreboard elements
    const scoreXElement = document.getElementById("scoreX");
    const scoreOElement = document.getElementById("scoreO");

    // Winning patterns
    const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
        [0, 4, 8], [2, 4, 6]             // Diagonals
    ];

    function handleCellClick(event) {
        if (!gameActive) return;
        const cell = event.target;
        const index = cell.getAttribute("data-index");

        if (board[index] !== "") return; // Prevent duplicate moves

        board[index] = currentPlayer;
        cell.innerText = currentPlayer;
        cell.classList.add("disabled");

        if (checkWin(currentPlayer)) {
            statusText.innerText = `Player ${currentPlayer} Wins!`;
            highlightWinningCells(currentPlayer);
            updateScore(currentPlayer);
            gameActive = false;
            return;
        }

        if (board.every(cell => cell !== "")) {
            statusText.innerText = "It's a Draw!";
            gameActive = false;
            return;
        }

        currentPlayer = currentPlayer === "X" ? "O" : "X";
        statusText.innerText = `Player ${currentPlayer}'s turn`;
    }

    function checkWin(player) {
        return winPatterns.some(pattern =>
            pattern.every(index => board[index] === player)
        );
    }

    function highlightWinningCells(player) {
        winPatterns.forEach(pattern => {
            if (pattern.every(index => board[index] === player)) {
                pattern.forEach(index => {
                    cells[index].style.backgroundColor = "gold"; // Light blue effect
                });
            }
        });
    }

    function updateScore(player) {
        if (player === "X") {
            scoreX++;
        } else {
            scoreO++;
        }
        updateScoreboard();
    }

    function updateScoreboard() {
        scoreXElement.innerText = scoreX;
        scoreOElement.innerText = scoreO;
    }

    function resetGame() {
        board.fill("");
        gameActive = true;
        currentPlayer = "X";
        statusText.innerText = "Player X's turn";
        cells.forEach(cell => {
            cell.innerText = "";
            cell.classList.remove("disabled");
            cell.style.backgroundColor = "white"; // Reset background
        });
    }

    document.getElementById("game-board").addEventListener("click", handleCellClick);
    restartButton.addEventListener("click", resetGame);
});
